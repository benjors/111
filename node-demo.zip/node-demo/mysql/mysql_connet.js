var db=require('./mysql');

// // 查询所有用户的用户名，密码 等于指定的值的用户数据
// db.query(`select user_name,password from users where user_name ='qqq' and password ='222'`, [],function(result,fields){
//     console.log('查询结果：',result);
// });
//查询所有用户的用户名，密码
// db.query(`select id,user_name,password from users`, [],function(result,fields){
//     console.log('查询结果：',result);
// });

// db.query('select * from users where id=1', [],function(result,fields){
//     console.log('查询结果：');
//     console.log(result);
// });

// db.query('select id, user_name from users where id=1', [],function(result,fields){
//     console.log('查询结果：');
//     console.log(result);
// });


//添加实例
// var  addSql = 'INSERT INTO users(user_name,password,created_at,enable) VALUES(?,?,?,?)';
// var  addSqlParams =['1112','666','1654340283584',0];
// db.query(addSql,addSqlParams,function(result,fields){
//     console.log('添加成功')
// })

//
// var  addSql = 'INSERT INTO users(user_name,password,created_at,enable) VALUES("111","222",1654340283584,0)';
// var  addSqlParams =[];
// db.query(addSql,addSqlParams,function(result,fields){
//     console.log('添加成功')
// })

// 添加好友
// var  addSql = 'INSERT INTO Friend(user_id,friend_id,created_at,enable) VALUES(?,?,?,?)';
// var  addSqlParams =['22','11','1654415182792',0];
// db.query(addSql,addSqlParams,function(result,fields){
//     console.log('添加成功',result)
// })

//好友列表查询
// db.query(`select id,user_id,friend_id from Friend`, [],function(result,fields){
//     console.log('查询结果：',result);
// });

//用户id==6的好友查询
db.query(`select id,user_id,friend_id from Friend where user_id=22`, [],function(result,fields){
    console.log('查询结果：',result);
});
