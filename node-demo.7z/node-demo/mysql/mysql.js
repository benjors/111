const mysql = require('mysql');
var databaseConfig = require('./config');  //引入数据库配置模块中的数据
var pool = mysql.createPool(databaseConfig);

// pool.on('acquire', function (connection) {
//     console.log(`获取数据库连接 [${connection.threadId}]`);
// });
// pool.on('connection', function (connection) {
//     console.log(`创建数据库连接 [${connection.threadId}]`);
// });
// pool.on('enqueue', function () {
//     console.log('正在等待可用数据库连接');
// });
// pool.on('release', function (connection) {
//     console.log(`数据库连接 [${connection.threadId}] 已释放`);
// });
//
// pool.on('error', function (err) {console.log(err)})


//向外暴露方法
module.exports = {
    query : function(sql,params,callback){
        //每次使用的时候需要创建链接，数据操作完成之后要关闭连接
        // 创建数据库连接池

        pool.getConnection(function(err, connection){
            if(err){
                console.error('连接失败: ' + err.stack);
                throw err;
            }
            console.log('连接成功 id ' + connection.threadId);
            //开始数据操作
            //传入三个参数，第一个参数sql语句，第二个参数sql语句中需要的数据，第三个参数回调函数
            connection.query( sql, params, function(err,results,fields ){
                if(err){
                    console.log('数据操作失败');
                    throw err;
                }

                //释放数据库连接对象
                connection.release();

                //将查询出来的数据返回给回调函数
                //results作为数据操作后的结果，fields作为数据库连接的一些字段
                callback && callback(results, fields);
            });
        });
    }
};




