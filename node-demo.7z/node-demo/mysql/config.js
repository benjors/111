//配置链接数据库参数
module.exports = {
    // host : 'localhost',
    // port : 3306,
    // user : 'root',
    // password : '147258369bb',
    // database : 'node_manager',
    // connectionLimit: 20, // 连接池允许创建的最大连接数，默认值为10
    // queueLimit: 0,//允许挂起的最大连接数,默认值为0,代表挂起的连接数无限制
    // multipleStatements: true, //  允许执行多条sql语句


    host : 'db4free.net',
    port : 3306,
    user : 'liudexi',
    password : '147258369bb',
    database : 'node_manager',
    connectionLimit: 20, // 连接池允许创建的最大连接数，默认值为10
    queueLimit: 0,//允许挂起的最大连接数,默认值为0,代表挂起的连接数无限制
    multipleStatements: true, //  允许执行多条sql语句

    // 账户中心：https://freedb.tech/dashboard/index.php
    // Email: 147258369bbb55@gmail.com
    // 147258369bb
    // 管理面板：https://phpmyadmin.freedb.tech/

    // host : 'sql.freedb.tech',
    // port :  3306,
    // user : 'freedb_liudexi',
    // password : 'Z88a2gHwKABuq?4',
    // database : 'freedb_node_manager',
    // connectionLimit: 50, // 连接池允许创建的最大连接数，默认值为10
    // queueLimit: 0,//允许挂起的最大连接数,默认值为0,代表挂起的连接数无限制
    // multipleStatements: true, //  允许执行多条sql语句

};
