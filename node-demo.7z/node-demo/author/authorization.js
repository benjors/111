const jwt = require("jsonwebtoken");

const secretKey = "4FtwLsLyeAVyuDgM";

// 生成token
module.exports.generateToken = function (payload) {
    const token = jwt.sign(payload, secretKey, {
            expiresIn: 24 * 60 * 60 * 1000, //days in the future, default  is 24 * 60 * 60 * 1000, expiresIn: 365 * 60 * 60 * 1000, max
        });
    return token;
};

// 验证token
module.exports.verifyToken = function (token) {
    return new Promise((resolve, reject) => {
        try{
            jwt.verify(token, secretKey, (err, decoded)=> {
                if (err) {
                    reject(err);
                } else {
                    resolve({ code: "200", msg: "token验证通过" }) ;
                }
            });

        }catch(e){
           return { code: "400", msg: "登录失败，token错误" };
        }
    });
};
