/*
* 子进程模块
我们可以使用 Node.js 的 child_process 模块很容易地衍生一个子进程，
* 并且那些父子进程使用一个消息系统相互之间可以很容易地交流。
child_process 模块使我们在一个运行良好的子进程内运行一些能够进入操作系统的命令。
* */
const fs = require('fs');
const child_process = require('child_process');//子进程

for(var i=0; i<3; i++) {
    var workerProcess = child_process.exec('node support.js '+i, function (error, stdout, stderr) {
        if (error) {
            console.log(error.stack);
            console.log('Error code: '+error.code);
            console.log('Signal received: '+error.signal);
        }
        console.log('stdout: ' + stdout);
        console.log('stderr: ' + stderr);
    });

    workerProcess.on('exit', function (code) {
        console.log('子进程已退出，退出码 '+code);
    });
}
