// 引入 events 模块

/*
* 事件驱动是 Node.js 的核心
* emit：触发一个监听函数
on：注册一个监听函数
* 在 Node.js 中一个很重要的模块 Events（EventEmitter 事件触发器），也称为发布/订阅模式，
* 为什么说它重要，因为在 Node.js 中绝大多数模块都依赖于此，
* 例如 Net、HTTP、FS、Stream 等，
* 除了这些系统模块比较知名的 Express、Koa 框架中也能看到 EventEmitter 的踪迹。
* */

var events = require('events');
// 创建 eventEmitter 对象
var eventEmitter = new events.EventEmitter();

// 创建事件处理程序
var connectHandler = function connected() {
    console.log('连接成功。');

    // 触发 data_received 事件
    eventEmitter.emit('data_received');
}

// 绑定 connection 事件处理程序
eventEmitter.on('connection', connectHandler);

// 使用匿名函数绑定 data_received 事件
eventEmitter.on('data_received', function(){
    console.log('数据接收成功。');
});

// 触发 connection 事件
eventEmitter.emit('connection');

console.log("程序执行完毕。");
